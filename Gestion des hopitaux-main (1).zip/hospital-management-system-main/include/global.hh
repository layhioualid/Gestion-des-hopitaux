#ifndef GLOBAL_HMS
#define GLOBAL_HMS
using namespace std;
#include <string>

extern int yyyymmdd;
int power(int n = 1, int exp = 0);
int strToNum(string s);
#endif // !GLOBAL_HMS